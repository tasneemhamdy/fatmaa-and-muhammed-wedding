export type LanternColor = 'gold' | 'rose' | 'emerald' | 'amber';

export interface Wish {
  id: string;
  name: string;
  message: string;
  timestamp: string;
  color: LanternColor;
}

export interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  isOver: boolean;
}
