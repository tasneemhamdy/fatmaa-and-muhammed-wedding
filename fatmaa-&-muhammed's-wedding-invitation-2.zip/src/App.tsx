import React, { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence, useScroll, useTransform, useSpring } from "motion/react";
import Countdown from "./components/Countdown";
import WeddingRings from "./components/WeddingRings";
import FloatingLanterns from "./components/FloatingLanterns";
import AudioPlayer from "./components/AudioPlayer";
import FallingPetals from "./components/FallingPetals";
import InteractiveSparkles from "./components/InteractiveSparkles";
import { Wish, LanternColor } from "./types";
import { Sparkles, Heart, ChevronDown, Award, Upload, Video, RefreshCw, Sliders, Settings } from "lucide-react";
// @ts-ignore
import heroBg from "./assets/images/wedding_hero_bg_1782283472702.jpg";

// Helper to resolve absolute api URLs for robust fetching in sandboxed contexts
function resolveApiUrl(path: string): string {
  try {
    const scriptOrigin = new URL(import.meta.url).origin;
    if (scriptOrigin && scriptOrigin !== "null" && !scriptOrigin.startsWith("blob:")) {
      return `${scriptOrigin}${path}`;
    }
  } catch (e) {}

  try {
    if (typeof window !== "undefined" && window.location && window.location.origin && window.location.origin !== "null") {
      return `${window.location.origin}${path}`;
    }
  } catch (e) {}

  return path;
}

export default function App() {
  const { scrollYProgress } = useScroll();
  
  // Custom parallax scroll animations for the background video:
  // - Subtly translate vertically downwards (parallax effect)
  // - Gently zoom/scale up the video on scroll to create organic depth
  const videoY = useTransform(scrollYProgress, [0, 1], ["0%", "8%"]);
  const videoScale = useTransform(scrollYProgress, [0, 1], [1.02, 1.12]);

  const [wishes, setWishes] = useState<Wish[]>([]);
  const [loading, setLoading] = useState(true);
  const [videoUrl, setVideoUrl] = useState<string>(resolveApiUrl("/api/background-video.mp4"));
  const [hasCustomVideo, setHasCustomVideo] = useState(false);
  const [videoOpacity, setVideoOpacity] = useState<number>(0.45);
  const [videoBlur, setVideoBlur] = useState<number>(0.5);
  const [videoSpeed, setVideoSpeed] = useState<number>(0.3); // animate slowly by default
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [showControls, setShowControls] = useState<boolean>(false);
  const [scrollScrub, setScrollScrub] = useState<boolean>(true); // default to scrubbing on scroll as requested!

  const videoRef = useRef<HTMLVideoElement | null>(null);

  // Smooth out scrollYProgress for beautiful butter-smooth playhead transitions
  const smoothedScrollYProgress = useSpring(scrollYProgress, {
    stiffness: 40,
    damping: 20,
    restDelta: 0.001
  });

  // Track scroll change to update video playhead slowly when scrubbing
  useEffect(() => {
    if (!scrollScrub) return;

    const unsubscribe = smoothedScrollYProgress.on("change", (latest) => {
      const video = videoRef.current;
      if (video && video.duration && !isNaN(video.duration) && isFinite(video.duration)) {
        // Map the scroll progress (0 to 1) to the video duration
        // Keep within safe duration boundaries to avoid empty/black frames
        const targetTime = Math.min(Math.max(latest * video.duration, 0), video.duration - 0.05);
        video.currentTime = targetTime;
      }
    });

    return () => unsubscribe();
  }, [scrollScrub, smoothedScrollYProgress]);

  // Adjust play/pause and playback rate depending on scrollScrub setting
  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      if (scrollScrub) {
        video.pause();
      } else {
        video.playbackRate = videoSpeed;
        video.play().catch(() => {});
      }
    }
  }, [scrollScrub, videoSpeed, videoUrl]);

  // Synchronize initial video current time on load
  const handleLoadedMetadata = () => {
    const video = videoRef.current;
    if (video && video.duration && isFinite(video.duration) && scrollScrub) {
      video.pause();
      const currentScroll = smoothedScrollYProgress.get();
      const targetTime = Math.min(Math.max(currentScroll * video.duration, 0), video.duration - 0.05);
      video.currentTime = targetTime;
    }
  };

  // Fetch all wishes from Express backend API
  async function fetchWishes() {
    try {
      const response = await fetch(resolveApiUrl("/api/wishes"));
      if (response.ok) {
        const data = await response.json();
        setWishes(data);
      }
    } catch (error) {
      console.error("Error fetching wishes:", error);
    } finally {
      setLoading(false);
    }
  }

  // Add a wish to Express backend API
  async function handleAddWish(name: string, message: string, color: LanternColor): Promise<boolean> {
    try {
      const response = await fetch(resolveApiUrl("/api/wishes"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, message, color }),
      });

      if (response.ok) {
        // Refresh wishes list to trigger floating animation
        await fetchWishes();
        return true;
      }
    } catch (error) {
      console.error("Error adding wish:", error);
    }
    return false;
  }

  // Delete a wish from Express backend API
  async function handleDeleteWish(id: string): Promise<boolean> {
    try {
      const response = await fetch(resolveApiUrl(`/api/wishes/${id}`), {
        method: "DELETE",
      });
      if (response.ok) {
        await fetchWishes();
        return true;
      }
    } catch (error) {
      console.error("Error deleting wish:", error);
    }
    return false;
  }

  // Process and save custom background video
  const processVideoFile = async (file: File) => {
    if (!file || !file.type.startsWith("video/")) {
      return;
    }

    // Create object URL to play instantly
    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    setHasCustomVideo(true);

    // Save to IndexedDB
    const request = indexedDB.open("wedding_db", 1);
    request.onupgradeneeded = (event) => {
      const db = (event.target as any).result;
      if (!db.objectStoreNames.contains("assets")) {
        db.createObjectStore("assets");
      }
    };
    request.onsuccess = (event) => {
      const db = (event.target as any).result;
      const tx = db.transaction("assets", "readwrite");
      tx.objectStore("assets").put(file, "background_video");
    };

    // Save to server-side filesystem permanently so it works for all users!
    try {
      await fetch(resolveApiUrl("/api/upload-video"), {
        method: "POST",
        body: file,
      });
    } catch (error) {
      console.error("Error uploading custom background video to server:", error);
    }
  };

  // Handle uploading custom background video
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processVideoFile(file);
    }
  };

  // Reset background video to original premium default
  const handleResetVideo = async () => {
    setVideoUrl(resolveApiUrl("/api/background-video.mp4"));
    setHasCustomVideo(false);

    // Remove from IndexedDB
    const request = indexedDB.open("wedding_db", 1);
    request.onsuccess = (event) => {
      const db = (event.target as any).result;
      const tx = db.transaction("assets", "readwrite");
      tx.objectStore("assets").delete("background_video");
    };

    // Remove from server
    try {
      await fetch(resolveApiUrl("/api/upload-video"), {
        method: "DELETE",
      });
    } catch (error) {
      console.error("Error deleting background video from server:", error);
    }
  };

  useEffect(() => {
    fetchWishes();
    
    // Poll for new wishes every 10 seconds to keep lanterns synchronized across guest browsers
    const interval = setInterval(fetchWishes, 10000);

    // Initialize/Load from IndexedDB and sync with server
    const request = indexedDB.open("wedding_db", 1);
    request.onupgradeneeded = (e) => {
      const db = (e.target as any).result;
      if (!db.objectStoreNames.contains("assets")) {
        db.createObjectStore("assets");
      }
    };
    request.onsuccess = (e) => {
      const db = (e.target as any).result;
      const tx = db.transaction("assets", "readonly");
      const getReq = tx.objectStore("assets").get("background_video");
      getReq.onsuccess = () => {
        const blob = getReq.result;
        if (blob) {
          const url = URL.createObjectURL(blob);
          setVideoUrl(url);
          setHasCustomVideo(true);
        } else {
          // Check if server has custom video active
          fetch(resolveApiUrl("/api/video-status"))
            .then((res) => res.json())
            .then((data) => {
              if (data.hasCustomVideo) {
                setHasCustomVideo(true);
                // Fetch the custom video from server, save to IndexedDB for ultra-smooth local caching
                fetch(resolveApiUrl("/api/background-video.mp4"))
                  .then((res) => {
                    if (!res.ok) throw new Error("Failed to download video from server");
                    return res.blob();
                  })
                  .then((videoBlob) => {
                    const saveTx = db.transaction("assets", "readwrite");
                    saveTx.objectStore("assets").put(videoBlob, "background_video");
                    const url = URL.createObjectURL(videoBlob);
                    setVideoUrl(url);
                  })
                  .catch((err) => {
                    console.error("Failed to pre-cache video:", err);
                    // Fallback to streaming directly from server
                    setVideoUrl(resolveApiUrl("/api/background-video.mp4"));
                  });
              }
            })
            .catch((err) => console.error("Error checking background video status on server:", err));
        }
      };
    };

    // Global drag and drop event listeners
    const handleDragOver = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(true);
    };

    const handleDragLeave = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);
    };

    const handleDrop = (e: DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setDragActive(false);

      const files = e.dataTransfer?.files;
      if (files && files.length > 0) {
        const file = files[0];
        if (file.type.startsWith("video/")) {
          processVideoFile(file);
        }
      }
    };

    window.addEventListener("dragover", handleDragOver);
    window.addEventListener("dragleave", handleDragLeave);
    window.addEventListener("drop", handleDrop);

    return () => {
      clearInterval(interval);
      window.removeEventListener("dragover", handleDragOver);
      window.removeEventListener("dragleave", handleDragLeave);
      window.removeEventListener("drop", handleDrop);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-950 via-gold-200/15 to-emerald-950 text-gold-50 selection:bg-gold-500 selection:text-emerald-950 font-sans relative overflow-x-hidden">
      
      {/* Background Star Overlay */}
      <div className="absolute inset-0 stars-bg opacity-30 pointer-events-none z-0" />

      {/* Floating Audio Player */}
      <AudioPlayer />

      {/* Falling Rose Petals */}
      <FallingPetals />

      {/* Cinematic Fixed Backdrop with looping background video or image fallback */}
      <motion.div 
        className="fixed inset-0 overflow-hidden pointer-events-none z-0"
        style={{
          y: videoY,
          scale: videoScale,
        }}
      >
        {videoUrl ? (
          <video
            key={videoUrl}
            autoPlay
            loop
            muted
            playsInline
            onLoadedMetadata={handleLoadedMetadata}
            className="w-full h-full object-cover transition-all duration-300"
            style={{
              opacity: videoOpacity,
              filter: `blur(${videoBlur}px)`,
            }}
            ref={(el) => {
              videoRef.current = el;
              if (el) {
                el.playbackRate = videoSpeed;
              }
            }}
          >
            <source
              src={videoUrl}
              type="video/mp4"
            />
            {/* Image fallback if video tag is unsupported */}
            <img
              src={heroBg}
              alt="Pyramids under starry twilight sky background"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-35"
            />
          </video>
        ) : (
          <img
            src={heroBg}
            alt="Pyramids under starry twilight sky background"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-30 transition-all duration-300 filter blur-[0.5px]"
          />
        )}
        {/* Soft elegant vignette gradient overlays to keep all text incredibly legible */}
        <div className="absolute inset-0 bg-gradient-to-b from-emerald-950/85 via-transparent to-emerald-950/95" />
      </motion.div>

      {/* Drag & Drop Fullscreen Overlay */}
      <AnimatePresence>
        {dragActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-emerald-950/90 backdrop-blur-lg z-50 flex flex-col items-center justify-center p-8 pointer-events-none"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 15 }}
              className="border-2 border-dashed border-gold-400/60 rounded-3xl p-12 max-w-lg w-full text-center bg-emerald-950/40 backdrop-blur-sm flex flex-col items-center gap-6 shadow-2xl relative"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-gold-500/5 via-transparent to-gold-500/5 rounded-3xl" />
              <div className="w-20 h-20 rounded-full bg-gold-500/10 border border-gold-500/30 flex items-center justify-center relative animate-pulse">
                <Video className="w-10 h-10 text-gold-300" />
                <Sparkles className="w-4 h-4 text-gold-400 absolute top-2 right-2 animate-bounce" />
              </div>
              <div className="space-y-2">
                <h3 className="font-display text-2xl font-bold text-gold-200 tracking-wider">
                  SET BACKDROP VIDEO
                </h3>
                <p className="font-serif text-sm text-gold-300/80 leading-relaxed italic">
                  Drop your custom wedding video file anywhere on this screen to instantly animate the webpage background
                </p>
              </div>
              <div className="text-[10px] font-mono uppercase tracking-[0.2em] text-gold-400/60 bg-gold-500/5 px-4 py-1.5 rounded-full border border-gold-500/10">
                Supports MP4, WEBM, MOV
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>



      {/* HERO SECTION */}
      <header className="relative min-h-screen flex flex-col items-center justify-between py-12 px-4 z-10" id="hero-section">
        
        {/* Subtle, random mouse-tracking sparkle animation */}
        <InteractiveSparkles />

        {/* TOP MONOGRAM & INITIALS */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex flex-col items-center text-center select-none"
        >
          <div className="w-20 h-20 relative flex items-center justify-center mb-2 drop-shadow-[0_8px_24px_rgba(0,0,0,0.6)]">
            {/* SVG Heart shape backdrop and gold stroke */}
            <svg
              viewBox="0 0 100 100"
              className="absolute inset-0 w-full h-full fill-emerald-950/70 stroke-gold-500/40 stroke-[2] overflow-visible"
            >
              <path
                d="M 50 24 C 36 6, 8 6, 8 38 C 8 64, 44 84, 50 90 C 56 84, 92 64, 92 38 C 92 6, 64 6, 50 24 Z"
              />
            </svg>
            <span className="font-display text-base font-semibold tracking-widest text-gold-300 z-10 pl-0.5 mt-1">F & M</span>
            <div className="absolute inset-[-4px] pointer-events-none">
              <svg
                viewBox="0 0 100 100"
                className="w-full h-full fill-none stroke-gold-500/20 stroke-[1] animate-pulse overflow-visible"
              >
                <path
                  d="M 50 22 C 34 3, 5 3, 5 38 C 5 66, 43 87, 50 93 C 57 87, 95 66, 95 38 C 95 3, 66 3, 50 22 Z"
                />
              </svg>
            </div>
          </div>
        </motion.div>

        {/* HERO CONTENT: NAMES & TYPOGRAPHY */}
        <div className="text-center my-auto max-w-4xl px-4 flex flex-col items-center">
          
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2, delay: 0.2 }}
            className="relative"
          >
            {/* Elegant luxury script wordmark */}
            <span className="font-script text-gold-400 text-4xl sm:text-5xl md:text-6xl tracking-wide block mb-2 filter drop-shadow-md">
              Save the Date
            </span>

            {/* Gorgeous, romantic script calligraphy for names */}
            <h1 className="font-script text-6xl sm:text-8xl md:text-[8rem] leading-tight text-gold-200 font-normal mt-2 select-all filter drop-shadow-[0_4px_12px_rgba(0,0,0,0.6)]">
              Fatmaa
              <span className="block text-2xl sm:text-3xl md:text-4xl font-serif font-light italic text-gold-400/85 tracking-normal lowercase my-1 sm:my-2 md:my-3">
                &amp;
              </span>
              Muhammed
            </h1>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-6 md:mt-8 max-w-xl mx-auto"
          >
            {/* Traditional Arabic wedding verse */}
            <p className="font-serif text-lg md:text-xl text-gold-200/95 leading-relaxed italic" lang="ar">
              "وَمِنْ آيَاتِهِ أَنْ خَلَقَ لَكُم مِّنْ أَنفُسِكُمْ أَزْوَاجًا لِّتَسْكُنُوا إِلَيْهَا"
            </p>
            <p className="font-serif text-xs md:text-sm text-gold-300/60 mt-2 tracking-wider">
              "And among His signs is that He created for you mates that you may find tranquility in them"
            </p>
          </motion.div>

          {/* Golden Egyptian geometric border ornament separator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.4 }}
            transition={{ delay: 0.8 }}
            className="flex items-center gap-4 w-full max-w-xs justify-center my-6"
          >
            <div className="h-[1px] bg-gradient-to-r from-transparent to-gold-500 flex-grow" />
            <Heart className="w-3.5 h-3.5 text-gold-400 fill-current animate-pulse" />
            <div className="h-[1px] bg-gradient-to-l from-transparent to-gold-500 flex-grow" />
          </motion.div>

          {/* COUNTDOWN COMPONENT */}
          <Countdown />
        </div>

        {/* BOTTOM SCROLL INDICATOR */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          transition={{ duration: 1, delay: 1 }}
          className="flex flex-col items-center cursor-pointer select-none group"
          onClick={() => {
            const ringsSec = document.getElementById("wedding-rings-section");
            if (ringsSec) ringsSec.scrollIntoView({ behavior: "smooth" });
          }}
        >
          <span className="font-display text-[10px] tracking-[0.25em] uppercase text-gold-300/80 group-hover:text-gold-200 transition-colors duration-300">
            Reveal Invitation
          </span>
          <ChevronDown className="w-5 h-5 text-gold-400 mt-1.5 animate-bounce" />
        </motion.div>

      </header>

      {/* THE WEDDING RINGS SECTION */}
      <section className="relative py-12 z-10">
        <WeddingRings />
      </section>

      {/* GUESTBOOK MEMORY WALL SECTION */}
      <section className="relative py-16 z-10">
        <div className="text-center mb-4">
          <span className="font-script text-gold-400 text-3xl md:text-4xl">Digital Memory Box</span>
          <h2 className="font-display text-2xl md:text-4xl text-gold-100 tracking-widest uppercase mt-1">
            Wishes &amp; Blessings
          </h2>
          <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-gold-500 to-transparent mx-auto mt-4" />
        </div>

        {/* Guestbook Canvas & Lit Form */}
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-gold-400">
            <div className="w-10 h-10 border-2 border-gold-500 border-t-transparent rounded-full animate-spin mb-4" />
            <span className="font-serif italic">Gathering wishing lanterns from the sky...</span>
          </div>
        ) : (
          <FloatingLanterns wishes={wishes} onAddWish={handleAddWish} onDeleteWish={handleDeleteWish} />
        )}
      </section>

      {/* LUXURY TRADITIONAL CLOSING SECTION */}
      <footer className="relative py-20 z-10 border-t border-gold-500/10 bg-black/40 backdrop-blur-sm" id="footer-section">
        <div className="max-w-4xl mx-auto px-4 text-center flex flex-col items-center">
          
          <div className="w-12 h-[1px] bg-gold-500/40 mb-6" />
          
          {/* Traditional arabic invitation closure */}
          <h3 className="font-display text-2xl text-gold-200 tracking-widest uppercase">
            We Can't Wait to Celebrate with You
          </h3>
          <p className="font-serif italic text-lg text-gold-300/80 mt-2 max-w-xl" lang="ar">
            "حضوركم يسعدنا ويشرفنا، دامت دياركم مكللة بالأفراح والمسرات"
          </p>
          <p className="font-serif text-sm text-gold-400/50 mt-2">
            "Your presence will honor us and fill our hearts with joy."
          </p>

          {/* Monogram closure */}
          <div className="mt-10 mb-4 font-display text-xl tracking-widest text-gold-400 font-bold select-none">
            F &amp; M
          </div>

          <div className="text-[11px] font-mono tracking-wider text-gold-500/40 uppercase select-none">
            © 2026 FATMA &amp; MUHAMMED • MADE WITH LOVE
          </div>
        </div>
      </footer>
    </div>
  );
}
