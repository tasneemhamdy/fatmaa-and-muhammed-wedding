import React, { useEffect, useRef } from "react";

interface SparkleParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  maxSize: number;
  opacity: number;
  fadeSpeed: number;
  rotation: number;
  rotationSpeed: number;
  growth: number; // 1 for growing, -1 for fading
}

export default function InteractiveSparkles() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const mouseRef = useRef({ x: 0, y: 0, active: false, moved: false });
  const lastSpawnRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let particles: SparkleParticle[] = [];

    // Resize canvas to match the parent container
    const resizeCanvas = () => {
      const rect = container.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };

    // Initialize resize
    resizeCanvas();
    const resizeObserver = new ResizeObserver(() => {
      resizeCanvas();
    });
    resizeObserver.observe(container);

    // Generate a single magical sparkle particle
    const createSparkle = (x: number, y: number, isMouseSparkle = true): SparkleParticle => {
      const angle = Math.random() * Math.PI * 2;
      const speed = isMouseSparkle ? 0.3 + Math.random() * 0.7 : 0.1 + Math.random() * 0.3;
      const maxSize = isMouseSparkle ? 6 + Math.random() * 8 : 4 + Math.random() * 5;
      
      return {
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - (0.2 + Math.random() * 0.3), // gentle upward drift
        size: 0.1, // starts tiny and grows
        maxSize,
        opacity: 0.2 + Math.random() * 0.4,
        fadeSpeed: isMouseSparkle ? 0.008 + Math.random() * 0.012 : 0.005 + Math.random() * 0.008,
        rotation: Math.random() * Math.PI,
        rotationSpeed: (Math.random() - 0.5) * 0.03,
        growth: 1, // growing mode
      };
    };

    // Handle mouse move to spawn particles
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const mX = e.clientX - rect.left;
      const mY = e.clientY - rect.top;

      // Track current position
      mouseRef.current.x = mX;
      mouseRef.current.y = mY;
      mouseRef.current.active = true;

      // Calculate distance from last spawn point
      const dx = mX - lastSpawnRef.current.x;
      const dy = mY - lastSpawnRef.current.y;
      const distance = Math.sqrt(dx * dx + dy * dy);

      // Only spawn when mouse moved a bit, to prevent massive particle lists
      if (distance > 12) {
        // Spawn 2 particles on path
        particles.push(createSparkle(mX, mY, true));
        if (Math.random() > 0.5) {
          particles.push(createSparkle(mX - dx / 2, mY - dy / 2, true));
        }
        lastSpawnRef.current = { x: mX, y: mY };
      }
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    // Attach events directly to the hero section or container fallback
    const target = document.getElementById("hero-section") || container;
    target.addEventListener("mousemove", handleMouseMove);
    target.addEventListener("mouseleave", handleMouseLeave);

    // Animation Loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Spontaneously generate subtle background sparkles
      if (Math.random() < 0.06 && particles.length < 40) {
        const randX = Math.random() * canvas.width;
        const randY = Math.random() * canvas.height;
        particles.push(createSparkle(randX, randY, false));
      }

      // 2. Render and update particles
      particles.forEach((p, index) => {
        // Grow/fade lifecycle
        if (p.growth === 1) {
          p.size += 0.5;
          if (p.size >= p.maxSize) {
            p.growth = -1; // start shrinking/fading
          }
        } else {
          p.opacity -= p.fadeSpeed;
          p.size -= p.fadeSpeed * p.maxSize;
        }

        // Apply velocities
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.rotationSpeed;

        // Draw particle if valid
        if (p.opacity > 0 && p.size > 0.5) {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);

          // Draw custom 4-pointed premium sparkle flare
          ctx.beginPath();
          ctx.moveTo(0, -p.size);
          ctx.quadraticCurveTo(0, 0, p.size, 0);
          ctx.quadraticCurveTo(0, 0, 0, p.size);
          ctx.quadraticCurveTo(0, 0, -p.size, 0);
          ctx.quadraticCurveTo(0, 0, 0, -p.size);
          ctx.closePath();

          // Elegant gold glow gradient
          const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, p.size);
          gradient.addColorStop(0, `rgba(243, 235, 215, ${p.opacity})`); // soft premium ivory gold
          gradient.addColorStop(0.35, `rgba(186, 160, 110, ${p.opacity * 0.9})`); // gold-400
          gradient.addColorStop(1, `rgba(186, 160, 110, 0)`); // fully transparent outer
          
          ctx.fillStyle = gradient;
          ctx.fill();

          // Subtle center core glow point
          ctx.beginPath();
          ctx.arc(0, 0, p.size * 0.25, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity * 0.95})`;
          ctx.fill();

          ctx.restore();
        }
      });

      // Filter out dead particles
      particles = particles.filter((p) => p.opacity > 0 && p.size > 0.5);

      animationFrameId = requestAnimationFrame(animate);
    };

    animate();

    // Cleanup on unmount
    return () => {
      target.removeEventListener("mousemove", handleMouseMove);
      target.removeEventListener("mouseleave", handleMouseLeave);
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div 
      ref={containerRef} 
      className="absolute inset-0 w-full h-full pointer-events-none z-10 overflow-hidden"
    >
      <canvas 
        ref={canvasRef} 
        className="block w-full h-full pointer-events-none"
      />
    </div>
  );
}
