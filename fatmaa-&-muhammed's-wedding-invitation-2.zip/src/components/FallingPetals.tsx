import React, { useEffect, useRef } from "react";

interface Butterfly {
  x: number;
  y: number;
  r: number; // size/scale radius
  speedX: number;
  speedY: number;
  opacity: number;
  rotation: number;
  rotationSpeed: number;
  swayAmplitude: number;
  swaySpeed: number;
  swayPhase: number;
  flapPhase: number;
  flapSpeed: number;
  colorType: number; // 0 for gold, 1 for amber, 2 for ivory
}

export default function FallingPetals() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Number of butterflies fluttering around
    const butterflyCount = 35;
    const butterflies: Butterfly[] = [];

    // Helper to generate a single butterfly
    function createButterfly(isInitial = false): Butterfly {
      const size = 3 + Math.random() * 5.5; // delicate, elegant tiny sizes
      return {
        x: Math.random() * width,
        y: isInitial ? Math.random() * height : height + 20, // enter from bottom or start scattered
        r: size,
        speedX: (Math.random() - 0.5) * 1.2, // horizontal drift speed
        speedY: -(0.4 + Math.random() * 0.8), // rising upwards gently like true butterflies
        opacity: 0.55 + Math.random() * 0.45, // glowing opacity
        rotation: (Math.random() - 0.5) * 45, // slight angle tilt
        rotationSpeed: (Math.random() - 0.5) * 0.5,
        swayAmplitude: 8 + Math.random() * 12, // subtle organic sideward flutter sway
        swaySpeed: 0.01 + Math.random() * 0.02,
        swayPhase: Math.random() * Math.PI * 2,
        flapPhase: Math.random() * Math.PI * 2,
        flapSpeed: 0.12 + Math.random() * 0.15, // rapid wing flapping speed
        colorType: Math.floor(Math.random() * 3), // gold, amber, ivory
      };
    }

    // Populate initial butterflies dispersed across the screen
    for (let i = 0; i < butterflyCount; i++) {
      butterflies.push(createButterfly(true));
    }

    // Update canvas size on resize
    function handleResize() {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }

    window.addEventListener("resize", handleResize);

    // Main animation draw loop
    function draw() {
      if (!ctx || !canvas) return;
      ctx.clearRect(0, 0, width, height);

      butterflies.forEach((b, index) => {
        // Physics update
        b.y += b.speedY; // gently float upwards
        b.swayPhase += b.swaySpeed;
        b.flapPhase += b.flapSpeed;
        b.rotation += b.rotationSpeed;

        // Keep rotation tilt within natural limits
        if (b.rotation > 30) {
          b.rotation = 30;
          b.rotationSpeed *= -1;
        } else if (b.rotation < -30) {
          b.rotation = -30;
          b.rotationSpeed *= -1;
        }

        // Apply sinusoidal sway to create the magical flutter horizontal path
        const currentX = b.x + Math.sin(b.swayPhase) * b.swayAmplitude + (b.speedX * b.swayPhase * 0.1);

        // Draw the butterfly
        ctx.save();
        ctx.translate(currentX, b.y);
        ctx.rotate((b.rotation * Math.PI) / 180);

        // Wing flap factor (horizontal scaling to represent flapping wings in 3D projection)
        const flapScale = Math.abs(Math.sin(b.flapPhase));

        // Create beautiful royal metallic/luminescent gradient for wings
        const wingGradient = ctx.createRadialGradient(0, 0, b.r * 0.2, 0, 0, b.r * 1.5);
        
        let baseColor = "255, 215, 0"; // Gold default
        if (b.colorType === 1) {
          baseColor = "253, 186, 116"; // Soft warm orange/amber (amber-300)
        } else if (b.colorType === 2) {
          baseColor = "255, 250, 240"; // Warm ivory/pearl
        }

        wingGradient.addColorStop(0, `rgba(${baseColor}, ${b.opacity})`);
        wingGradient.addColorStop(0.5, `rgba(${baseColor}, ${b.opacity * 0.7})`);
        wingGradient.addColorStop(1, `rgba(${baseColor}, 0)`); // elegant glow fade at tips

        ctx.fillStyle = wingGradient;

        // 1. Left upper wing
        ctx.beginPath();
        ctx.ellipse(-b.r * 0.65 * flapScale, -b.r * 0.4, b.r * 0.7 * flapScale, b.r * 0.9, -Math.PI / 10, 0, Math.PI * 2);
        ctx.fill();

        // 2. Left lower wing
        ctx.beginPath();
        ctx.ellipse(-b.r * 0.5 * flapScale, b.r * 0.35, b.r * 0.45 * flapScale, b.r * 0.55, Math.PI / 10, 0, Math.PI * 2);
        ctx.fill();

        // 3. Right upper wing
        ctx.beginPath();
        ctx.ellipse(b.r * 0.65 * flapScale, -b.r * 0.4, b.r * 0.7 * flapScale, b.r * 0.9, Math.PI / 10, 0, Math.PI * 2);
        ctx.fill();

        // 4. Right lower wing
        ctx.beginPath();
        ctx.ellipse(b.r * 0.5 * flapScale, b.r * 0.35, b.r * 0.45 * flapScale, b.r * 0.55, -Math.PI / 10, 0, Math.PI * 2);
        ctx.fill();

        // 5. Central slim elegant body
        ctx.beginPath();
        ctx.ellipse(0, -b.r * 0.1, b.r * 0.1, b.r * 0.75, 0, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(254, 240, 138, ${b.opacity * 0.95})`; // bright soft yellow body
        ctx.fill();

        // 6. Tiny subtle glowing core
        ctx.beginPath();
        ctx.arc(0, -b.r * 0.1, b.r * 0.15, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255, 255, 255, ${b.opacity * 0.8})`;
        ctx.fill();

        ctx.restore();

        // Recycle if fluttered off the top
        if (b.y < -30) {
          // Re-spawn at bottom
          butterflies[index] = createButterfly(false);
        }
      });

      animationFrameId = requestAnimationFrame(draw);
    }

    draw();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-20 w-full h-full"
      style={{ mixBlendMode: "screen" }}
    />
  );
}
