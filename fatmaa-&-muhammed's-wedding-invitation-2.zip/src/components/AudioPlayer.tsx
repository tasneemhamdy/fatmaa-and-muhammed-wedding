import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Music, Volume2, VolumeX, Sparkles } from "lucide-react";

// Note Frequencies in Hz for Pachelbel's "Canon in D" (Romantic Classic)
const D2 = 73.42;
const Fsh2 = 92.50;
const G2 = 98.00;
const A2 = 110.00;
const B2 = 123.47;
const Csh3 = 138.59;
const D3 = 146.83;
const E3 = 164.81;
const Fsh3 = 185.00;
const G3 = 196.00;
const A3 = 220.00;
const B3 = 246.94;
const Csh4 = 277.18;
const D4 = 293.66;
const E4 = 329.63;
const Fsh4 = 369.99;
const G4 = 392.00;
const A4 = 440.00;
const B4 = 493.88;
const Csh5 = 554.37;
const D5 = 587.33;
const E5 = 659.25;
const Fsh5 = 739.99;

interface SynthNote {
  time: number;
  freq: number;
  duration: number;
  type: OscillatorType;
  gain: number;
}

const canonInDNotes: SynthNote[] = [];

// Helper to push chord notes
function addChord(time: number, freqs: number[], duration = 2.0) {
  freqs.forEach((f) => {
    canonInDNotes.push({
      time,
      freq: f,
      duration,
      type: "sine",
      gain: 0.012, // extremely soft warm cathedral organ pads
    });
  });
}

// Helper to push melody notes
function addMelody(time: number, freq: number, duration = 0.8) {
  canonInDNotes.push({
    time,
    freq,
    duration,
    type: "triangle", // clear celestial chimes/bell sound
    gain: 0.035, // slightly more distinct
  });
}

// Helper to push decorative sparkling arpeggio notes
function addSparkle(time: number, freq: number, duration = 0.4) {
  canonInDNotes.push({
    time,
    freq,
    duration,
    type: "sine",
    gain: 0.02,
  });
}

// --- POPULATE PACHeLBEL'S CANON IN D ---
// 1. D Major
addChord(0.0, [D3, Fsh3, A3, D4], 2.0);
addMelody(0.0, Fsh4, 0.8);
addSparkle(0.0, D4, 0.4);
addSparkle(0.5, Fsh4, 0.4);
addSparkle(1.0, A4, 0.4);
addSparkle(1.5, Fsh4, 0.4);

// 2. A Major
addChord(2.0, [A2, E3, A3, Csh4], 2.0);
addMelody(2.0, E4, 0.8);
addSparkle(2.0, Csh4, 0.4);
addSparkle(2.5, E4, 0.4);
addSparkle(3.0, A4, 0.4);
addSparkle(3.5, E4, 0.4);

// 3. B Minor
addChord(4.0, [B2, Fsh3, B3, D4], 2.0);
addMelody(4.0, D4, 0.8);
addSparkle(4.0, B3, 0.4);
addSparkle(4.5, D4, 0.4);
addSparkle(5.0, Fsh4, 0.4);
addSparkle(5.5, D4, 0.4);

// 4. F# Minor
addChord(6.0, [Fsh2, Csh3, Fsh3, A3], 2.0);
addMelody(6.0, Csh4, 0.8);
addSparkle(6.0, A3, 0.4);
addSparkle(6.5, Csh4, 0.4);
addSparkle(7.0, Fsh4, 0.4);
addSparkle(7.5, Csh4, 0.4);

// 5. G Major
addChord(8.0, [G2, D3, G3, B3], 2.0);
addMelody(8.0, B3, 0.8);
addSparkle(8.0, G3, 0.4);
addSparkle(8.5, B3, 0.4);
addSparkle(9.0, D4, 0.4);
addSparkle(9.5, B3, 0.4);

// 6. D Major
addChord(10.0, [D3, Fsh3, A3, D4], 2.0);
addMelody(10.0, A3, 0.8);
addSparkle(10.0, Fsh3, 0.4);
addSparkle(10.5, A3, 0.4);
addSparkle(11.0, D4, 0.4);
addSparkle(11.5, A3, 0.4);

// 7. G Major
addChord(12.0, [G2, D3, G3, B3], 2.0);
addMelody(12.0, B3, 0.8);
addSparkle(12.0, G3, 0.4);
addSparkle(12.5, B3, 0.4);
addSparkle(13.0, D4, 0.4);
addSparkle(13.5, B3, 0.4);

// 8. A Major
addChord(14.0, [A2, E3, A3, Csh4], 2.0);
addMelody(14.0, Csh4, 0.8);
addSparkle(14.0, E3, 0.4);
addSparkle(14.5, A3, 0.4);
addSparkle(15.0, Csh4, 0.4);
addSparkle(15.5, E4, 0.4);

// Additional Measure - Celestial High Arpeggio Turn (16.0s to 24.0s)
// 9. D Major
addChord(16.0, [D3, Fsh3, A3], 2.0);
addMelody(16.0, D5, 0.6);
addMelody(16.6, Csh5, 0.4);
addMelody(17.2, B4, 0.4);
addMelody(17.8, A4, 0.4);

// 10. A Major
addChord(18.0, [A2, E3, A3], 2.0);
addMelody(18.0, G4, 0.6);
addMelody(18.6, Fsh4, 0.4);
addMelody(19.2, E4, 0.4);
addMelody(19.8, D4, 0.4);

// 11. B Minor
addChord(20.0, [B2, Fsh3, B3], 2.0);
addMelody(20.0, Fsh4, 0.6);
addMelody(20.6, G4, 0.4);
addMelody(21.2, A4, 0.4);
addMelody(21.8, B4, 0.4);

// 12. A Major
addChord(22.0, [A2, E3, A3], 2.0);
addMelody(22.0, Csh5, 0.6);
addMelody(22.6, D5, 0.4);
addMelody(23.2, E5, 0.4);
addMelody(23.8, Fsh5, 0.4);

// Resolving End
addChord(24.0, [D3, Fsh3, A3, D4, Fsh4, D5], 4.0);


export default function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const intervalIdRef = useRef<number | null>(null);
  const delayNodeRef = useRef<DelayNode | null>(null);

  // Play the entire Pachelbel's "Canon in D" sequence ahead using exact timeline scheduling
  function playCanonInDSequence(baseTime: number) {
    const ctx = audioCtxRef.current;
    if (!ctx) return;

    canonInDNotes.forEach((note) => {
      const playTime = baseTime + note.time;
      
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc.type = note.type;
      osc.frequency.setValueAtTime(note.freq, playTime);

      // Ultra lush volume envelope to represent wedding chimes and soft organ pads
      gainNode.gain.setValueAtTime(0, playTime);
      gainNode.gain.linearRampToValueAtTime(note.gain, playTime + 0.1); // gentle soft attack
      gainNode.gain.exponentialRampToValueAtTime(0.0001, playTime + note.duration);

      // Route through delay/reverb unit if present
      if (delayNodeRef.current) {
        osc.connect(gainNode);
        gainNode.connect(delayNodeRef.current);
      } else {
        osc.connect(gainNode);
        gainNode.connect(ctx.destination);
      }

      osc.start(playTime);
      osc.stop(playTime + note.duration);
    });
  }

  // Master clock loops every 28 seconds
  function startLoop() {
    const ctx = audioCtxRef.current;
    if (!ctx) return;

    const loopTime = ctx.currentTime;
    playCanonInDSequence(loopTime);

    // Schedule next iteration slightly before it finishes
    const interval = window.setInterval(() => {
      if (audioCtxRef.current) {
        playCanonInDSequence(audioCtxRef.current.currentTime);
      }
    }, 28000);

    intervalIdRef.current = interval;
  }

  // Start audio engine
  async function startAudio() {
    try {
      if (!audioCtxRef.current) {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtxClass();
        audioCtxRef.current = ctx;

        // Create lush cathedral-like delay feedback loop for wedding dreamscape vibe
        const delay = ctx.createDelay(5.0);
        const feedback = ctx.createGain();
        const delayGain = ctx.createGain();

        delay.delayTime.value = 0.5; // 500ms lush echo
        feedback.gain.value = 0.4;   // soft feedback trails
        delayGain.gain.value = 0.35; // reverb wet mix volume

        delay.connect(feedback);
        feedback.connect(delay);

        delay.connect(delayGain);
        delayGain.connect(ctx.destination);

        delayNodeRef.current = delay;
      }

      if (audioCtxRef.current.state === "suspended") {
        await audioCtxRef.current.resume();
      }

      startLoop();
      setIsPlaying(true);
    } catch (error) {
      console.error("Web Audio initialization blocked or failed:", error);
    }
  }

  // Stop audio engine
  function stopAudio() {
    if (intervalIdRef.current) {
      clearInterval(intervalIdRef.current);
      intervalIdRef.current = null;
    }
    setIsPlaying(false);
  }

  function handleToggle() {
    if (isPlaying) {
      stopAudio();
    } else {
      startAudio();
    }
  }

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (intervalIdRef.current) {
        clearInterval(intervalIdRef.current);
      }
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
      }
    };
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-50 flex items-center gap-3">
      {/* Cinematic ambient music controller */}
      <motion.button
        id="ambient-music-trigger"
        onClick={handleToggle}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.95 }}
        className={`w-12 h-12 rounded-full flex items-center justify-center border shadow-2xl transition-all duration-300 relative group cursor-pointer ${
          isPlaying
            ? "bg-gradient-to-r from-gold-600 to-gold-500 text-emerald-950 border-gold-400"
            : "bg-emerald-950/80 backdrop-blur-md text-gold-400 border-gold-500/20 hover:border-gold-400"
        }`}
      >
        {/* Pulsing visual circles to indicate audio state */}
        {isPlaying && (
          <>
            <span className="absolute inset-0 rounded-full bg-gold-400/30 animate-ping pointer-events-none" />
            <span className="absolute inset-[-4px] rounded-full bg-gold-400/10 animate-pulse pointer-events-none" />
          </>
        )}

        <AnimatePresence mode="wait">
          {isPlaying ? (
            <motion.div
              key="playing"
              initial={{ opacity: 0, rotate: -45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: 45 }}
              className="relative"
            >
              <Volume2 className="w-5 h-5 stroke-[2]" />
              <Sparkles className="w-3 h-3 text-emerald-950 absolute -top-1.5 -right-1.5 animate-pulse" />
            </motion.div>
          ) : (
            <motion.div
              key="paused"
              initial={{ opacity: 0, rotate: 45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: -45 }}
            >
              <VolumeX className="w-5 h-5 stroke-[1.8]" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hover Tooltip */}
        <div className="absolute left-14 bg-emerald-950 border border-gold-500/20 text-gold-100 text-[11px] font-display uppercase tracking-widest px-3 py-1.5 rounded-xl opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-300 shadow-xl whitespace-nowrap">
          {isPlaying ? "Mute Romantic Melody" : 'Play "Canon in D" Melody'}
        </div>
      </motion.button>
    </div>
  );
}
