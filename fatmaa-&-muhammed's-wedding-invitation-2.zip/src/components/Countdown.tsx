import { useEffect, useState } from "react";
import { motion } from "motion/react";
import { TimeLeft } from "../types";

export default function Countdown() {
  // Target wedding date: June 28, 2026 at 19:00 (7:00 PM) Egypt Time (UTC+3 / EEST - Daylight Saving Time is active in June in Egypt)
  const weddingDate = new Date("2026-06-28T19:00:00+03:00");

  const [timeLeft, setTimeLeft] = useState<TimeLeft>({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isOver: false,
  });

  useEffect(() => {
    function calculateTime() {
      const now = new Date();
      const difference = weddingDate.getTime() - now.getTime();

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isOver: true });
        return;
      }

      const d = Math.floor(difference / (1000 * 60 * 60 * 24));
      const h = Math.floor((difference / (1000 * 60 * 60)) % 24);
      const m = Math.floor((difference / 1000 / 60) % 60);
      const s = Math.floor((difference / 1000) % 60);

      setTimeLeft({
        days: d,
        hours: h,
        minutes: m,
        seconds: s,
        isOver: false,
      });
    }

    calculateTime();
    const interval = setInterval(calculateTime, 1000);

    return () => clearInterval(interval);
  }, []);

  const timeUnits = [
    { label: "Days", value: timeLeft.days, labelAr: "أيام" },
    { label: "Hours", value: timeLeft.hours, labelAr: "ساعات" },
    { label: "Minutes", value: timeLeft.minutes, labelAr: "دقائق" },
    { label: "Seconds", value: timeLeft.seconds, labelAr: "ثواني" },
  ];

  if (timeLeft.isOver) {
    return (
      <div className="text-center py-6">
        <motion.p
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="font-display text-2xl md:text-3xl lg:text-4xl text-gold-400 tracking-widest uppercase"
        >
          Today is the Big Day! 🎉
        </motion.p>
        <p className="font-serif italic text-gold-200 mt-2 text-lg">
          اليوم هو يوم العمر! ربنا يجمع بينكم في خير
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-wrap justify-center gap-4 md:gap-8 max-w-4xl mx-auto px-4 py-6">
      {timeUnits.map((unit, index) => (
        <motion.div
          key={unit.label}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          whileHover={{ y: -5, scale: 1.03 }}
          className="relative group min-w-[80px] sm:min-w-[110px] md:min-w-[130px] aspect-square flex flex-col items-center justify-center bg-emerald-950/40 backdrop-blur-md rounded-2xl border border-gold-500/30 p-4 shadow-xl transition-all duration-300 hover:border-gold-400 hover:shadow-gold-500/10 hover:shadow-2xl"
          id={`countdown-unit-${unit.label.toLowerCase()}`}
        >
          {/* Inner ambient gold glow */}
          <div className="absolute inset-0 bg-radial from-gold-500/5 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          
          {/* Top/Bottom divider for subtle flip card or depth effect */}
          <div className="absolute left-0 right-0 top-1/2 h-[1px] bg-emerald-900/40" />

          {/* Golden glow numbering */}
          <span className="font-display text-3xl sm:text-4xl md:text-5xl font-semibold text-gold-300 group-hover:text-gold-200 transition-colors duration-300 filter drop-shadow-[0_0_10px_rgba(212,175,55,0.3)] select-none">
            {String(unit.value).padStart(2, "0")}
          </span>

          <span className="font-display text-[9px] sm:text-[11px] md:text-xs text-gold-400 group-hover:text-gold-300 tracking-wider uppercase mt-2 select-none">
            {unit.label}
          </span>
          <span className="font-serif text-[10px] sm:text-xs text-gold-200/60 mt-0.5 select-none font-light italic">
            {unit.labelAr}
          </span>
        </motion.div>
      ))}
    </div>
  );
}
