import React from "react";
import { motion } from "motion/react";
import { Sparkles, Heart } from "lucide-react";

export default function WeddingRings() {
  // Beautiful golden gradient styles
  const goldGradientClass = "bg-gradient-to-r from-gold-300 via-gold-100 to-gold-500 bg-clip-text text-transparent";

  return (
    <div className="max-w-4xl mx-auto px-4 mt-16 text-center" id="wedding-rings-section">
      
      {/* Elegantly styled header */}
      <div className="text-center mb-10">
        <span className="font-script text-gold-400 text-3xl md:text-4xl">The Sacred Union</span>
        <h2 className="font-display text-2xl md:text-4xl text-gold-100 tracking-widest uppercase mt-1">
          Eternal Bond
        </h2>
        <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-gold-500 to-transparent mx-auto mt-4" />
      </div>

      {/* Main interactive golden rings card */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.0, ease: "easeOut" }}
        className="relative bg-emerald-950/65 backdrop-blur-md border border-gold-500/25 rounded-3xl p-8 md:p-12 shadow-2xl overflow-hidden max-w-2xl mx-auto"
      >
        {/* Subtle background glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-gold-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Ring Animation Stage */}
        <div className="relative h-64 flex items-center justify-center mb-8">
          
          {/* Sparkles around rings */}
          <div className="absolute inset-0 pointer-events-none">
            <motion.div
              animate={{ 
                opacity: [0.3, 1, 0.3], 
                scale: [0.8, 1.2, 0.8],
                rotate: [0, 90, 180]
              }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
              className="absolute top-1/4 left-1/4 text-gold-300"
            >
              <Sparkles className="w-5 h-5 opacity-70" />
            </motion.div>
            <motion.div
              animate={{ 
                opacity: [0.2, 0.8, 0.2], 
                scale: [1, 0.7, 1],
                rotate: [45, 135, 225]
              }}
              transition={{ repeat: Infinity, duration: 5, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-1/4 right-1/4 text-gold-400"
            >
              <Sparkles className="w-4 h-4 opacity-50" />
            </motion.div>
          </div>

          {/* Intertwining Rings 3D Stage */}
          <div className="relative w-80 h-48 flex items-center justify-center perspective-1000">
            
            {/* LEFT RING - Groom (Muhammed) */}
            <motion.div
              animate={{
                rotateY: [-10, 10, -10],
                rotateX: [15, 25, 15],
                y: [0, -4, 0],
              }}
              transition={{
                repeat: Infinity,
                duration: 6,
                ease: "easeInOut"
              }}
              style={{ transformStyle: "preserve-3d" }}
              className="absolute left-10 w-36 h-36 rounded-full border-[10px] border-double border-gold-400 flex items-center justify-center shadow-[0_0_30px_rgba(212,175,55,0.45)] cursor-pointer group"
            >
              {/* Golden metallic inner ring styling */}
              <div className="absolute inset-0.5 rounded-full border-2 border-gold-200/40 pointer-events-none" />
              <div className="absolute inset-2 rounded-full border border-gold-600/30 pointer-events-none bg-emerald-950/30" />
              
              {/* Groom's Name Inscribed inside Ring */}
              <div className="text-center z-10 select-all transform -rotate-12 group-hover:scale-105 transition-transform">
                <span className="font-serif text-xxs tracking-[0.2em] text-gold-400/70 block uppercase font-medium">Groom</span>
                <span className="font-script text-lg font-bold text-gold-100 block filter drop-shadow">Muhammed</span>
              </div>

              {/* Shimmer reflection sweep effect */}
              <motion.div
                animate={{ x: ["-100%", "100%"] }}
                transition={{ repeat: Infinity, duration: 3, ease: "linear", repeatDelay: 2 }}
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 rounded-full pointer-events-none"
              />
            </motion.div>

            {/* RIGHT RING - Bride (Fatmaa) */}
            <motion.div
              animate={{
                rotateY: [10, -10, 10],
                rotateX: [20, 10, 20],
                y: [0, 4, 0],
              }}
              transition={{
                repeat: Infinity,
                duration: 6,
                ease: "easeInOut",
                delay: 0.5
              }}
              style={{ transformStyle: "preserve-3d" }}
              className="absolute right-10 w-36 h-36 rounded-full border-[10px] border-double border-gold-300 flex items-center justify-center shadow-[0_0_30px_rgba(212,175,55,0.45)] z-10 cursor-pointer group"
            >
              {/* Golden metallic inner ring styling */}
              <div className="absolute inset-0.5 rounded-full border-2 border-gold-100/40 pointer-events-none" />
              <div className="absolute inset-2 rounded-full border border-gold-500/30 pointer-events-none bg-emerald-950/30" />

              {/* Sparkly diamond head on top of the Bride's ring */}
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-7 h-7 rotate-45 bg-gradient-to-br from-white via-cyan-100 to-gold-200 border-2 border-gold-400 flex items-center justify-center shadow-[0_0_15px_rgba(255,255,255,0.9)] animate-pulse">
                <div className="w-2.5 h-2.5 bg-white rounded-full" />
              </div>
              
              {/* Bride's Name Inscribed inside Ring */}
              <div className="text-center z-10 select-all transform rotate-12 group-hover:scale-105 transition-transform">
                <span className="font-serif text-xxs tracking-[0.2em] text-gold-400/70 block uppercase font-medium">Bride</span>
                <span className="font-script text-lg font-bold text-gold-100 block filter drop-shadow">Fatmaa</span>
              </div>

              {/* Shimmer reflection sweep effect */}
              <motion.div
                animate={{ x: ["-100%", "100%"] }}
                transition={{ repeat: Infinity, duration: 3, ease: "linear", repeatDelay: 1.5 }}
                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/25 to-transparent skew-x-12 rounded-full pointer-events-none"
              />
            </motion.div>

          </div>
        </div>

        {/* Groom & Bride Names banner */}
        <div className="mb-6">
          <h3 className="font-script text-3xl sm:text-4xl text-gold-200 tracking-wide">
            Fatmaa <span className="font-serif text-lg text-gold-400/80 italic font-light">&amp;</span> Muhammed
          </h3>
          <div className="flex items-center justify-center gap-3 mt-2">
            <div className="h-[1px] w-8 bg-gold-500/20" />
            <Heart className="w-3.5 h-3.5 text-gold-400 fill-current animate-pulse" />
            <div className="h-[1px] w-8 bg-gold-500/20" />
          </div>
        </div>

        {/* Elegant Congratulations Sentences (English & Arabic) */}
        <div className="space-y-4 max-w-lg mx-auto">
          <p className="font-serif text-base sm:text-lg text-gold-100/90 leading-relaxed italic">
            "Warmest congratulations to the radiant couple! May your beautiful union be crowned with endless laughter, deep harmony, and a lifetime of shared dreams come true."
          </p>
          
          <div className="py-2">
            <p className="font-serif text-xl text-gold-300 leading-relaxed font-normal" lang="ar">
              "مبارك للعروسين الجميلين، بارك الله لكما وبارك عليكما وجمع بينكما في خير وعافية وسعادة أبدية."
            </p>
          </div>
        </div>

        {/* Subtle decorative framing corners */}
        <div className="absolute top-3 left-3 w-4 h-4 border-t border-l border-gold-500/30 rounded-tl-md" />
        <div className="absolute top-3 right-3 w-4 h-4 border-t border-r border-gold-500/30 rounded-tr-md" />
        <div className="absolute bottom-3 left-3 w-4 h-4 border-b border-l border-gold-500/30 rounded-bl-md" />
        <div className="absolute bottom-3 right-3 w-4 h-4 border-b border-r border-gold-500/30 rounded-br-md" />

      </motion.div>
    </div>
  );
}
