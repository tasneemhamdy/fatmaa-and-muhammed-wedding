import React, { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Wish, LanternColor } from "../types";
import { Sparkles, MessageCircle, Heart, User, Send, Trash2 } from "lucide-react";

interface LanternState {
  id: string;
  x: number;      // initial start X (percentage 5% to 95%)
  y: number;      // current bottom position in pixels (starts from -50 to containerHeight)
  speed: number;  // floating speed
  sway: number;   // sway amplitude
  swaySpeed: number; // sway speed
  phase: number;  // sine phase
  scale: number;  // depth scale (0.6 to 1.3)
  color: LanternColor;
}

interface FloatingLanternsProps {
  wishes: Wish[];
  onAddWish: (name: string, message: string, color: LanternColor) => Promise<boolean>;
  onDeleteWish: (id: string) => Promise<boolean>;
}

export default function FloatingLanterns({ wishes, onAddWish, onDeleteWish }: FloatingLanternsProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const animationRef = useRef<number | null>(null);
  const lanternsStateRef = useRef<Map<string, LanternState>>(new Map());

  // React state for the wish that is currently clicked/hovered for detail view
  const [selectedWish, setSelectedWish] = useState<Wish | null>(null);
  const [hoveredWishId, setHoveredWishId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Form states for guest sign-in
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [selectedColor, setSelectedColor] = useState<LanternColor>("gold");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [formError, setFormError] = useState("");

  const colorThemes: Record<LanternColor, { glow: string; text: string; bg: string; border: string; particle: string }> = {
    gold: {
      glow: "rgba(212, 175, 55, 0.7)",
      text: "text-gold-300",
      bg: "from-amber-500/80 to-gold-600/80",
      border: "border-gold-300/60",
      particle: "bg-gold-400",
    },
    rose: {
      glow: "rgba(244, 63, 94, 0.7)",
      text: "text-rose-300",
      bg: "from-rose-500/80 to-pink-600/80",
      border: "border-rose-300/60",
      particle: "bg-rose-400",
    },
    emerald: {
      glow: "rgba(16, 185, 129, 0.7)",
      text: "text-emerald-300",
      bg: "from-emerald-500/80 to-teal-600/80",
      border: "border-emerald-300/60",
      particle: "bg-emerald-400",
    },
    amber: {
      glow: "rgba(245, 158, 11, 0.7)",
      text: "text-amber-300",
      bg: "from-amber-600/80 to-orange-600/80",
      border: "border-amber-300/60",
      particle: "bg-amber-400",
    },
  };

  // Initialize and synchronize physics states with the incoming wishes
  useEffect(() => {
    const containerHeight = containerRef.current?.clientHeight || 550;
    const currentStates = lanternsStateRef.current;

    // Remove any states for wishes that no longer exist
    const wishIds = new Set(wishes.map((w) => w.id));
    for (const id of currentStates.keys()) {
      if (!wishIds.has(id)) {
        currentStates.delete(id);
      }
    }

    // Add states for new wishes
    wishes.forEach((wish) => {
      if (!currentStates.has(wish.id)) {
        // Distribute nicely
        const isNewArrival = Date.now() - new Date(wish.timestamp).getTime() < 10000;
        
        currentStates.set(wish.id, {
          id: wish.id,
          x: 5 + Math.random() * 90, // 5% to 95%
          // If newly created, start at the very bottom. Otherwise disperse vertically
          y: isNewArrival ? -40 : Math.random() * containerHeight,
          speed: 0.35 + Math.random() * 0.45, // steady float up speed
          sway: 15 + Math.random() * 25,     // pixels sway left and right
          swaySpeed: 0.008 + Math.random() * 0.015,
          phase: Math.random() * Math.PI * 2,
          scale: 0.65 + Math.random() * 0.65, // 3D depth scaling
          color: wish.color || "gold",
        });
      }
    });
  }, [wishes]);

  // Main high-performance Animation Loop
  useEffect(() => {
    let lastTime = 0;

    function updatePhysics(timestamp: number) {
      if (!lastTime) lastTime = timestamp;
      const containerHeight = containerRef.current?.clientHeight || 550;
      const containerWidth = containerRef.current?.clientWidth || 800;
      const states = lanternsStateRef.current;

      states.forEach((state) => {
        // Skip physics if hovered
        const isCurrentlyHovered = hoveredWishId === state.id || (selectedWish && selectedWish.id === state.id);
        
        if (!isCurrentlyHovered) {
          // Rise up
          state.y += state.speed;
          
          // Sway phase increment
          state.phase += state.swaySpeed;

          // Wrap around if floated off screen top
          if (state.y > containerHeight + 60) {
            state.y = -60;
            state.x = 5 + Math.random() * 90; // Re-roll horizontal start
          }
        }

        // Apply styles to physical elements directly (bypassing React re-render)
        const el = document.getElementById(`lantern-${state.id}`);
        if (el) {
          const startXPixels = (state.x / 100) * containerWidth;
          const swayOffset = Math.sin(state.phase) * state.sway;
          const currentX = startXPixels + swayOffset;

          // Calculate a nice fade-in at bottom and fade-out near top
          let opacity = 1.0;
          if (state.y < 60) {
            opacity = state.y / 60; // fade in from bottom
          } else if (state.y > containerHeight - 80) {
            opacity = Math.max(0, (containerHeight - state.y) / 80); // fade out at top
          }

          // Force hardware acceleration and apply 3D transform
          el.style.transform = `translate3d(${currentX}px, -${state.y}px, 0) scale(${state.scale})`;
          el.style.opacity = opacity.toFixed(2);
          el.style.zIndex = Math.round(state.scale * 100).toString();
        }
      });

      animationRef.current = requestAnimationFrame(updatePhysics);
    }

    animationRef.current = requestAnimationFrame(updatePhysics);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [hoveredWishId, selectedWish]);

  // Handle wish submission
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError("");

    if (!name.trim()) {
      setFormError("Please share your beautiful name.");
      return;
    }
    if (!message.trim()) {
      setFormError("Please leave a blessing for the happy couple.");
      return;
    }

    setIsSubmitting(true);
    try {
      const success = await onAddWish(name, message, selectedColor);
      if (success) {
        setName("");
        setMessage("");
        setSubmitSuccess(true);
        setTimeout(() => setSubmitSuccess(false), 5000);
      } else {
        setFormError("A little breeze blew away your wish. Please try again.");
      }
    } catch (err) {
      setFormError("Unable to reach the wishing well right now.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch max-w-7xl mx-auto px-4 mt-16" id="digital-memory-box">
      
      {/* LEFT: Floating Lantern Sky Workspace (Memory Wall) */}
      <div className="lg:col-span-7 flex flex-col justify-between bg-emerald-950/65 backdrop-blur-md border border-gold-500/25 rounded-3xl p-6 shadow-2xl relative overflow-hidden h-[600px]">
        
        {/* Twinkling star layout inside sky */}
        <div className="absolute inset-0 stars-bg opacity-30 pointer-events-none" />
        
        {/* Sky Ambient lighting */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-80 h-80 bg-gold-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 inset-x-0 h-28 bg-gradient-to-t from-emerald-900/60 to-transparent pointer-events-none" />

        {/* Heading */}
        <div className="relative z-10 flex items-center justify-between border-b border-gold-500/10 pb-4">
          <div>
            <h3 className="font-display text-xl md:text-2xl text-gold-200 tracking-wide">
              Lantern Sky Memory Wall
            </h3>
            <p className="font-serif italic text-gold-300/70 text-sm mt-0.5">
              Hover over floating lanterns to read blessings for Fatmaa & Muhammed
            </p>
          </div>
          <div className="flex items-center gap-2 bg-gold-500/10 border border-gold-500/20 px-3 py-1 rounded-full text-xs text-gold-300 font-mono">
            <Sparkles className="w-3.5 h-3.5 text-gold-400 animate-pulse" />
            <span>{wishes.length} Lanterns Lit</span>
          </div>
        </div>

        {/* PHYSICAL LANTERN SKY CONTAINER */}
        <div
          ref={containerRef}
          className="relative flex-grow overflow-hidden w-full h-[400px] select-none mt-4 cursor-pointer"
        >
          {wishes.map((wish) => {
            const theme = colorThemes[wish.color as LanternColor] || colorThemes.gold;
            const isHovered = hoveredWishId === wish.id;
            const isSelected = selectedWish?.id === wish.id;
            
            // Generate initials for the lantern body text
            const initials = wish.name
              ? wish.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase()
                  .substring(0, 2)
              : "♥";

            return (
              <div
                key={wish.id}
                id={`lantern-${wish.id}`}
                className="absolute bottom-0 left-0 transition-shadow duration-300 ease-out pointer-events-auto"
                style={{
                  willChange: "transform, opacity",
                  // Box shadow glow for the lantern
                  boxShadow: isHovered || isSelected ? `0 0 35px 8px ${theme.glow}` : `0 0 18px 2px ${theme.glow}`,
                }}
                onMouseEnter={() => setHoveredWishId(wish.id)}
                onMouseLeave={() => setHoveredWishId(null)}
                onClick={() => {
                  setSelectedWish(wish);
                  setDeleteConfirmId(null);
                }}
              >
                {/* Visual Lantern Body */}
                <div
                  className={`w-11 h-16 rounded-t-full rounded-b-xl bg-gradient-to-b ${theme.bg} border-t-2 ${theme.border} flex flex-col items-center justify-center relative cursor-pointer`}
                >
                  {/* Outer delicate gold binding line */}
                  <div className="absolute inset-x-1.5 inset-y-1 bg-transparent border border-gold-300/15 rounded-t-full rounded-b-lg pointer-events-none" />

                  {/* Initials glowing inside */}
                  <span className="font-display text-[10px] tracking-tighter text-gold-100 font-medium filter drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]">
                    {initials}
                  </span>

                  {/* Lantern Hanging Tassel / String */}
                  <div className="absolute bottom-[-10px] w-[2px] h-[10px] bg-gold-400/80 left-1/2 -translate-x-1/2 flex items-center justify-center">
                    {/* Small gold bead at end of string */}
                    <div className="w-[4px] h-[4px] bg-gold-300 rounded-full absolute bottom-0" />
                  </div>

                  {/* Glowing flame flicker element inside bottom */}
                  <div className="absolute bottom-1 w-2.5 h-3 bg-amber-300 rounded-full blur-[1px] animate-pulse opacity-90" />
                </div>
              </div>
            );
          })}

          {/* EMPTY STATE */}
          {wishes.length === 0 && (
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6 text-gold-300/40">
              <MessageCircle className="w-12 h-12 mb-3 stroke-[1.2]" />
              <p className="font-serif italic text-lg">Be the very first to light a wishing lantern...</p>
              <p className="text-xs mt-1">شاركونا التهاني لتضيء سماء الفرح</p>
            </div>
          )}
        </div>

        {/* REAL-TIME OVERLAY FOR DISPLAYING THE HOVERED/CLICKED WISH */}
        <div className="relative z-10 h-[100px] mt-2 border-t border-gold-500/10 pt-3 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {(selectedWish || (hoveredWishId && wishes.find((w) => w.id === hoveredWishId))) ? (
              (() => {
                const wishToDisplay = selectedWish || wishes.find((w) => w.id === hoveredWishId);
                if (!wishToDisplay) return null;
                const theme = colorThemes[wishToDisplay.color as LanternColor] || colorThemes.gold;

                return (
                  <motion.div
                    key={wishToDisplay.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -15 }}
                    transition={{ duration: 0.3 }}
                    className="w-full flex items-start gap-4 bg-emerald-950/90 border border-gold-400/30 p-3 rounded-2xl shadow-xl max-h-[100px] overflow-y-auto"
                    id={`active-lantern-details-${wishToDisplay.id}`}
                  >
                    <div className={`p-2 rounded-full bg-gold-500/10 border ${theme.border} flex-shrink-0 mt-1`}>
                      <Heart className={`w-4 h-4 ${theme.text} fill-current`} />
                    </div>
                    <div className="flex-grow text-left">
                      <div className="flex items-center justify-between">
                        <h4 className="font-display text-sm font-semibold text-gold-300 select-all">
                          {wishToDisplay.name}
                        </h4>
                        <span className="text-[10px] text-gold-200/50 font-mono">
                          {new Date(wishToDisplay.timestamp).toLocaleDateString(undefined, {
                            month: "short",
                            day: "numeric",
                          })}
                        </span>
                      </div>
                      <p className="font-serif text-sm italic text-gold-100/90 leading-relaxed mt-0.5 select-all">
                        "{wishToDisplay.message}"
                      </p>
                    </div>
                    {selectedWish && selectedWish.id === wishToDisplay.id && (
                      <div className="flex flex-col gap-1.5 self-start flex-shrink-0 min-w-[100px]">
                        {deleteConfirmId === wishToDisplay.id ? (
                          <div className="flex flex-col gap-1 p-1 bg-red-950/40 rounded-lg border border-red-500/30 text-center">
                            <span className="text-[9px] text-red-300 font-sans font-medium">Delete?</span>
                            <div className="flex gap-1 justify-center">
                              <button
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  const success = await onDeleteWish(wishToDisplay.id);
                                  if (success) {
                                    setSelectedWish(null);
                                    setDeleteConfirmId(null);
                                  }
                                }}
                                className="text-[9px] bg-red-500 text-white px-1.5 py-0.5 rounded hover:bg-red-600 transition-colors font-mono cursor-pointer font-bold"
                              >
                                Yes
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDeleteConfirmId(null);
                                }}
                                className="text-[9px] bg-zinc-800 text-gold-200 px-1.5 py-0.5 rounded hover:bg-zinc-700 transition-colors font-mono cursor-pointer"
                              >
                                No
                              </button>
                            </div>
                          </div>
                        ) : (
                          <>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setDeleteConfirmId(wishToDisplay.id);
                              }}
                              className="text-[10px] text-red-400 hover:text-red-300 cursor-pointer px-2 py-1 font-mono hover:bg-red-500/10 rounded-lg transition-colors flex items-center gap-1"
                              title="Delete message"
                            >
                              <Trash2 className="w-3 h-3" />
                              Delete
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedWish(null);
                              }}
                              className="text-[10px] text-gold-400 hover:text-gold-200 cursor-pointer px-2 py-1 font-mono hover:bg-gold-500/10 rounded-lg transition-colors text-left"
                            >
                              ✕ Close
                            </button>
                          </>
                        )}
                      </div>
                    )}
                  </motion.div>
                );
              })()
            ) : (
              <motion.div
                key="placeholder-prompt"
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                className="text-center font-serif italic text-gold-300/40 text-sm py-4"
              >
                "May your hearts forever beat as one..." - Light a lantern to add your blessing
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* RIGHT: Lit Wishing Well Form */}
      <div className="lg:col-span-5 bg-gradient-to-b from-emerald-950/75 to-emerald-900/75 backdrop-blur-md border border-gold-500/25 rounded-3xl p-6 shadow-2xl flex flex-col justify-between" id="lantern-form-container">
        <div>
          <div className="text-center mb-6">
            <div className="w-12 h-12 bg-gold-500/10 rounded-full flex items-center justify-center border border-gold-400/30 mx-auto mb-3">
              <Sparkles className="w-6 h-6 text-gold-400 animate-pulse" />
            </div>
            <h3 className="font-display text-2xl text-gold-200 tracking-wide">
              Light a Wishing Lantern
            </h3>
            <p className="font-serif italic text-gold-100/70 text-sm mt-1">
              أرسل تهنئة تضيء سماء العروسين
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Guest Name input */}
            <div>
              <label htmlFor="guest-name" className="block text-xs font-display uppercase tracking-wider text-gold-400 mb-1.5">
                Your Beautiful Name / الاسم الكِريم
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gold-400/60">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  id="guest-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Sarah & Hany"
                  maxLength={50}
                  className="w-full bg-emerald-950/60 border border-gold-500/20 rounded-xl py-3 pl-10 pr-4 text-gold-100 placeholder-gold-300/30 focus:outline-none focus:border-gold-400/70 transition-colors duration-200 font-serif text-base"
                />
              </div>
            </div>

            {/* Warm blessing input */}
            <div>
              <label htmlFor="guest-message" className="block text-xs font-display uppercase tracking-wider text-gold-400 mb-1.5">
                Blessing & Message / التهنئة الرقيقة
              </label>
              <div className="relative">
                <textarea
                  id="guest-message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Write your wishes, blessings, or lovely memories for Fatmaa & Muhammed here..."
                  maxLength={300}
                  rows={4}
                  className="w-full bg-emerald-950/60 border border-gold-500/20 rounded-xl p-3.5 text-gold-100 placeholder-gold-300/30 focus:outline-none focus:border-gold-400/70 transition-colors duration-200 font-serif text-base resize-none"
                />
                <div className="text-[10px] text-right text-gold-300/40 font-mono mt-1">
                  {message.length}/300 characters
                </div>
              </div>
            </div>

            {/* Lantern color selection */}
            <div>
              <label className="block text-xs font-display uppercase tracking-wider text-gold-400 mb-2">
                Choose Lantern Aura / لون الفانوس
              </label>
              <div className="flex gap-4">
                {(Object.keys(colorThemes) as LanternColor[]).map((col) => {
                  const active = selectedColor === col;
                  const theme = colorThemes[col];
                  return (
                    <button
                      key={col}
                      type="button"
                      onClick={() => setSelectedColor(col)}
                      className={`relative flex-1 aspect-square rounded-xl p-2 flex flex-col items-center justify-center border transition-all duration-300 cursor-pointer ${
                        active
                          ? "bg-gold-500/10 border-gold-400 shadow-md shadow-gold-500/5"
                          : "bg-emerald-950/40 border-gold-500/10 hover:border-gold-400/30"
                      }`}
                    >
                      {/* Little mini lantern sphere representation */}
                      <div
                        className={`w-4 h-5 rounded-t-full rounded-b bg-gradient-to-b ${theme.bg} border border-gold-300/30 shadow-inner`}
                        style={{ boxShadow: `0 0 10px 2px ${theme.glow}` }}
                      />
                      <span className="text-[10px] font-mono text-gold-200 mt-1 capitalize select-none">
                        {col}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {formError && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-red-400 text-xs font-serif italic text-center"
              >
                {formError}
              </motion.div>
            )}

            {submitSuccess && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-emerald-300 text-xs font-serif italic text-center"
              >
                ✨ Thank you! Your lantern is now glowing in the sky! ✨
              </motion.div>
            )}

            {/* Launch button */}
            <motion.button
              whileTap={{ scale: 0.98 }}
              type="submit"
              disabled={isSubmitting}
              className="w-full relative overflow-hidden group py-3.5 bg-gradient-to-r from-gold-600 via-gold-500 to-gold-700 text-emerald-950 rounded-xl font-display font-semibold uppercase tracking-widest text-xs transition-all duration-300 shadow-xl hover:shadow-gold-500/20 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-emerald-950 border-t-transparent rounded-full animate-spin" />
                  Lighting Lantern...
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  Light & Float Lantern / إشعال الفانوس
                </>
              )}
            </motion.button>
          </form>
        </div>

        {/* Traditional Blessing Footnote */}
        <div className="border-t border-gold-500/10 pt-4 mt-6 text-center text-gold-200/50 text-[11px] font-serif italic leading-relaxed select-none">
          "بَارَكَ اللَّهُ لَكُمَا وَبَارَكَ عَلَيْكُمَا وَجَمَعَ بَيْنَكُمَا فِي خَيْرٍ"<br />
          "May Allah bless you both and bring you together in goodness."
        </div>
      </div>
    </div>
  );
}
